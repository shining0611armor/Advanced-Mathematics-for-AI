import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import random

def feature_extractor(image):
    rows = 3	
    cols = 3

    kernels = list()
    output_images = list()

    sobel_kernel = [[-1, 0, 1],
                    [-2, 0, 2],
                    [-1, 0, 1]]
    kernels.append(sobel_kernel)

    A = 5
    for iteration in range(A):  
        image_height, image_width = len(image), len(image[0])
        kernel_height, kernel_width = len(kernels[iteration]), len(kernels[iteration][0])
        pad_h, pad_w = kernel_height // 2, kernel_width // 2

        padded_image = [[0] * (image_width + 2 * pad_w) for _ in range(image_height + 2 * pad_h)]
        for i in range(image_height):
            for j in range(image_width):
                padded_image[i + pad_h][j + pad_w] = image[i][j]

        output_image = [[0] * image_width for _ in range(image_height)]
        for x in range(image_height):  
            for y in range(image_width):
                sum_value = 0
                for m in range(kernel_height):
                    for n in range(kernel_width):
                        sum_value += (
                            padded_image[x + m][y + n] * kernels[iteration][m][n]
                        )
                output_image[x][y] = min(max(int(sum_value), 0), 255)

        random_kernel = [[random.randint(-2, 2) for _ in range(cols)] for _ in range(rows)]
        max_value = max(abs(num) for row in random_kernel for num in row)
        n_kernel = [[num / max_value if max_value != 0 else 0 for num in row] for row in random_kernel]
        kernels.append(n_kernel)  

        output_images.append(output_image)

    return output_images

image_path = "Lenna.png"  
image = Image.open(image_path).convert("L")  
image_array = np.array(image).tolist()  

opencv_image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

convolved_image = feature_extractor(image_array)
convolved_image_array = np.array(convolved_image, dtype=np.uint8)

k=0

plt.figure(figsize=(12, 4))  
plt.subplot(1, 2, 1)
plt.title("Original Image")
plt.imshow(opencv_image, cmap="gray")

plt.subplot(1, 2, 2) 
plt.title("output")
plt.imshow(convolved_image_array[k], cmap="gray")

plt.tight_layout()
plt.show()
